package myProject;

import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class ModelComputador extends JPanel {
    private ImageIcon imageTocado, imageHundido, imageAgua;
    private CasillaHumano matriz2;
    private int fila;
    private int columna;


    /**
     * Class Constructor
     */
    public ModelComputador(){
        matriz2 = new CasillaHumano(fila, columna);
        /*
        Los numero con el que identificamos los barcos son los siguientes
        Portaaviones ->1
        Submarinos -> 2
        Destructores -> 3
        Fragats -> 4
        */

    }

    public void ataques( int[][] matriz1, CasillaHumano matriz2){
        Random aleatorio = new Random();
        fila = aleatorio.nextInt(10);
        columna= aleatorio.nextInt(10);
        for(int i=0; i<matriz1.length ;i++){
            for(int j = 0; j<matriz1[i].length; j++){
                if(matriz1[fila][columna]== 1 || matriz1[fila][columna]== 2 || matriz1[fila][columna]== 3){ //recorre la matriz de la logica y pinta en la matriz del gui
                    /*imageTocado = new ImageIcon(getClass().getResource("/recursos/bomba 1.png"));
                    imageTocado = new ImageIcon(imageTocado.getImage().getScaledInstance(20,20, Image.SCALE_SMOOTH));
                    matriz2.setIcon(imageTocado);
                    matriz2.setContentAreaFilled(false);*/
                    matriz1[fila][columna] = 5;

                }
                if(matriz1[fila][columna]== 4){
                    /*imageHundido = new ImageIcon(getClass().getResource("/recursos/fuego.png"));
                    imageHundido = new ImageIcon(imageHundido.getImage().getScaledInstance(20,20, Image.SCALE_SMOOTH));
                    matriz2.setIcon(imageHundido);
                    matriz2.setContentAreaFilled(false);*/
                    matriz1[fila][columna] = 6;
                }
                if(matriz1[fila][columna]== 0){
                   /* imageAgua = new ImageIcon(getClass().getResource("/recursos/equis.png"));
                    imageAgua = new ImageIcon(imageAgua.getImage().getScaledInstance(20,20, Image.SCALE_SMOOTH));
                    matriz2.setIcon(imageAgua);
                    matriz2.setContentAreaFilled(false);*/
                    matriz1[fila][columna] = 0;

                }
            }
        }
    }

}
