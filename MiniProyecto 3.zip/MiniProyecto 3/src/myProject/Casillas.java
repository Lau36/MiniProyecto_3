package myProject;

import javax.swing.*;

public class Casillas extends JPanel {
    private JButton[][] nCasillas;
    private int numero_Filas;
    private int numero_Columnas;

    public void Casillas() {
        nCasillas = null;
        numero_Columnas = 10;
        numero_Filas = 10;
    }

    public void ordenar() {
        int ancho = this.getWidth();
        int alto = this.getHeight();

        int altoCasillas = alto / 10;
        int anchoCasillas = ancho / 10;

        for (int i = 0; i < numero_Filas; i++) {
            for (int j = 0; j < numero_Columnas; j++){

                //Se obtiene una referencia al boton actual
                JButton casilla = nCasillas[i][j];


            }
        }


}

    public void inicializar(){
        nCasillas = new JButton[numero_Filas][numero_Columnas];
        for(int i=0; i<numero_Filas; i++){
            for(int j=0; j<numero_Columnas; j++){
                JButton casilla = new JButton();
                this.add(casilla);//agrega los Jlabels al panel
                nCasillas[i][j] = casilla;

            }
        }
    }

}
